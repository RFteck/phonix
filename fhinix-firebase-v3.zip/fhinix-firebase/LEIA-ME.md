# Fhinix

Assistente pessoal e diário privado com ativação por voz. Funciona sozinho: **sem servidor, sem chave de API e sem plano pago**. Tudo roda no navegador.

## Como ele é independente

- **Núcleo essencial (sempre ativo, instantâneo, funciona offline):** hora e data, cálculos, conversões, dias até uma data, timers e lembretes, sorteios, diário (anotar, procurar, ler), seu nome.
- **IA local (opcional):** um modelo de linguagem (Qwen2.5) que roda na GPU do seu aparelho via WebGPU. Toque em **IA local** uma vez: o download (cerca de 1 GB) acontece só na primeira vez, fica salvo no navegador e depois funciona sem internet. Nenhum texto seu sai do aparelho.

## Arquivos

- `public/index.html`: a interface (abertura da fênix, console, voz, diário).
- `public/brain.js`: o núcleo (habilidades locais e carregamento da IA local).
- `public/hub.js`: palmas, Spotify, Gmail, Agenda, notícias e a rotina do resumo.
- `public/firebase-config.js`: configuração do Firebase, do Spotify e das preferências do resumo.
- `firestore.rules`: cada pessoa acessa só as próprias memórias.
- `firebase.json`: configuração do Hosting.

## Publicar no Firebase Hosting (plano gratuito)

```
npm install -g firebase-tools
firebase login
firebase use --add
firebase deploy --only hosting
```

Pronto. Não precisa do plano Blaze, de Functions nem de segredos.

## Sincronizar o diário entre aparelhos (opcional)

1. No console do Firebase, ative **Authentication > Google** e crie o **Firestore**.
2. Em **Configurações do projeto > Seus apps**, crie um app da Web e cole a configuração em `public/firebase-config.js`.
3. `firebase deploy` (inclui as regras de segurança).

Sem isso, o diário fica salvo só no aparelho em uso.

## Palmas, Spotify, Gmail, Agenda e notícias

Toque **Ativar voz** uma vez e **bata duas palmas**. O Fhinix:

1. começa a tocar sua música no Spotify (volume baixo enquanto ele fala);
2. lê as **principais notícias**;
3. lê seus **compromissos e reuniões** de hoje (e os primeiros de amanhã);
4. lê só os **e-mails importantes** não lidos e informa quantos ignorou (promoções, newsletters, notificações automáticas e códigos de verificação).
   Nada é apagado nem arquivado: a permissão é **somente leitura**.

Bater duas palmas durante o resumo interrompe a leitura; com música tocando, pausa a música. No **Painel** (coluna da direita) há o medidor de palmas com sensibilidade ajustável, os botões de conexão e os cartões de cada seção.

Comandos de voz: "resumo do dia", "notícias", "quais minhas reuniões", "meus e-mails", "toque Legião Urbana", "toque uma playlist de rock", "pausa", "continua", "próxima", "volume 40", "o que está tocando".

### Ativar o Gmail e a Agenda (uma vez)

O mesmo login Google do Fhinix serve para tudo, sem chave nova.

1. No Console do Firebase: **Authentication > Sign-in method > Google** (ativar) e criar o **Firestore**.
2. No Google Cloud (projeto `phonix-7a5fd`), em **APIs e serviços > Biblioteca**, ative **Gmail API** e **Google Calendar API**.
3. Em **APIs e serviços > Tela de permissão OAuth**: deixe em modo **Teste**, adicione seu e-mail em **Usuários de teste** e inclua os escopos `gmail.readonly` e `calendar.readonly`. O Google mostrará "app não verificado" no primeiro login: **Avançado > Continuar** (é o seu próprio app).
4. `firebase deploy` e, no site, toque em **Entrar**. O acesso dura cerca de 1 hora; depois disso, o Painel mostra "Desconectado" e basta tocar em **Conectar Google** de novo.

### Ativar o Spotify (uma vez)

1. Em https://developer.spotify.com/dashboard crie um app e cadastre o Redirect URI `https://phonix-7a5fd.web.app/`.
2. Cole o **Client ID** em `public/firebase-config.js` (campo `spotify.clientId`). Não use o Client Secret.
3. `firebase deploy`, abra o site, vá ao **Painel** e toque em **Conectar** ao lado de Spotify. Essa conexão fica salva e se renova sozinha.
4. Tocar música exige **Spotify Premium**. Funciona de dois jeitos: tocando no próprio navegador (Chrome/Edge no computador) ou controlando o app do Spotify que estiver aberto no celular/computador.

### Limites das palmas

- A aba precisa ficar aberta, com o microfone liberado. Em celular a escuta pausa com a tela apagada; o ideal é um computador ou tablet fixo.
- Barulho forte e contínuo (ou música muito alta) reduz a precisão; ajuste a sensibilidade no Painel olhando o medidor.

## Como usar por voz

1. Abra o site no Chrome ou no Edge e toque em **Ativar voz** uma vez (o navegador pede o microfone e libera a fala do Fhinix).
2. Diga **"Fhinix, acorde"**. Ele toca um sinal, abre o console e cumprimenta.
3. Fale normalmente. Depois de cada resposta ele continua ouvindo por cerca de 12 segundos sem precisar do nome. Diga "tchau" para ele voltar a esperar.

Exemplos:
- "Fhinix, anote que amanhã tenho reunião às 9"
- "Fhinix, me lembre em 10 minutos de tomar água"
- "Fhinix, quanto é 15% de 240?"
- "Fhinix, o que anotei sobre viagem?"
- "Fhinix, quantos dias faltam para o Natal?"
- "Fhinix, converta 10 km para milhas"
- "Fhinix, me chame de Rafael"

## Limites que vale saber

- **A IA local é pequena.** Ela conversa e responde bem em português, mas erra mais que modelos grandes na nuvem e pode inventar fatos. O núcleo essencial (cálculos, diário, lembretes) não tem esse problema, porque é regra exata.
- A IA local pede WebGPU (Chrome ou Edge atualizados) e cerca de 2 GB livres de memória de vídeo/RAM. Em aparelhos fracos, use o modelo menor indicado em `firebase-config.js`.
- O **reconhecimento de voz** usa o serviço do próprio navegador e precisa de internet. Firefox não tem esse recurso. Digitar sempre funciona.
- A escuta só funciona com a aba aberta; no celular, ela pausa quando a tela apaga. Lembretes e timers também só disparam com a aba aberta.
- Se o navegador escrever o nome de outro jeito (por exemplo "fênix"), ele já aceita algumas variações. Dá para ajustar a constante `WAKE` do `index.html`.
