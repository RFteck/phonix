/* Fhinix · núcleo independente.
 * Tudo roda no navegador: sem servidor, sem chave de API, sem serviço de terceiros.
 *  - Camada 1: habilidades locais (hora, cálculo, lembretes, diário, conversões...). Instantâneas e offline.
 *  - Camada 2: IA de linguagem opcional (WebLLM), baixada uma vez e executada na GPU do próprio aparelho.
 */
(function () {
  'use strict';

  const norm = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  const pad = (n) => String(n).padStart(2, '0');
  const pick = (a) => a[Math.floor(Math.random() * a.length)];

  /* ---------- números por extenso (0 a 99) ---------- */
  const UNITS = { zero: 0, um: 1, uma: 1, dois: 2, duas: 2, tres: 3, quatro: 4, cinco: 5, seis: 6, sete: 7, oito: 8, nove: 9, dez: 10, onze: 11, doze: 12, treze: 13, quatorze: 14, catorze: 14, quinze: 15, dezesseis: 16, dezessete: 17, dezoito: 18, dezenove: 19 };
  const TENS = { vinte: 20, trinta: 30, quarenta: 40, cinquenta: 50, sessenta: 60, setenta: 70, oitenta: 80, noventa: 90 };
  function wordsToDigits(s) {
    return s.replace(/\b(vinte|trinta|quarenta|cinquenta|sessenta|setenta|oitenta|noventa)(?:\s+e\s+(um|uma|dois|duas|tres|quatro|cinco|seis|sete|oito|nove))?\b/g, (_, t, u) => String(TENS[t] + (u ? UNITS[u] : 0)))
      .replace(/\b(zero|um|uma|dois|duas|tres|quatro|cinco|seis|sete|oito|nove|dez|onze|doze|treze|quatorze|catorze|quinze|dezesseis|dezessete|dezoito|dezenove)\b/g, (w) => String(UNITS[w]));
  }
  function fmtNum(x) {
    if (!isFinite(x)) return 'indefinido';
    const r = Math.round(x * 1e6) / 1e6;
    return r.toLocaleString('pt-BR', { maximumFractionDigits: 6 });
  }

  /* ---------- calculadora segura (sem eval) ---------- */
  function calc(expr) {
    const toks = expr.match(/\d+(?:\.\d+)?|[()+\-*/^%]|sqrt/g);
    if (!toks || toks.join('').length < expr.replace(/\s/g, '').length) return null;
    let i = 0;
    const peek = () => toks[i];
    function primary() {
      const t = toks[i++];
      if (t === undefined) throw 0;
      if (t === '(') { const v = add(); if (toks[i++] !== ')') throw 0; return v; }
      if (t === '-') return -unary();
      if (t === '+') return unary();
      if (t === 'sqrt') return Math.sqrt(unary());
      if (/^\d/.test(t)) return parseFloat(t);
      throw 0;
    }
    function unary() { return primary(); }
    function pow() { let b = unary(); if (peek() === '^') { i++; b = Math.pow(b, pow()); } return b; }
    function mul() {
      let v = pow();
      while (peek() === '*' || peek() === '/' || peek() === '%') {
        const o = toks[i++]; const r = pow();
        v = o === '*' ? v * r : o === '/' ? v / r : v % r;
      }
      return v;
    }
    function add() {
      let v = mul();
      while (peek() === '+' || peek() === '-') { const o = toks[i++]; const r = mul(); v = o === '+' ? v + r : v - r; }
      return v;
    }
    try { const v = add(); return i === toks.length ? v : null; } catch (_) { return null; }
  }
  function mathFrom(n) {
    let s = wordsToDigits(n);
    const pc = /(\d+(?:,\d+)?)\s*(?:%|por cento)\s*de\s*(\d+(?:,\d+)?)/.exec(s);
    if (pc) return parseFloat(pc[1].replace(',', '.')) / 100 * parseFloat(pc[2].replace(',', '.'));
    s = s.replace(/raiz (?:quadrada )?de\s*(\d+(?:,\d+)?)/g, 'sqrt($1)')
      .replace(/(\d)\s*,\s*(\d)/g, '$1.$2')
      .replace(/elevado a(?: potencia)?|\bao quadrado\b/g, (m) => (m === 'ao quadrado' ? '^2' : '^'))
      .replace(/\bmais\b/g, '+').replace(/\bmenos\b/g, '-')
      .replace(/\bvezes\b|\bmultiplicado por\b|(\d)\s*x\s*(?=\d)/g, (m, d) => (d ? d + '*' : '*'))
      .replace(/\bdividido por\b|\bdividido\b|\bsobre\b/g, '/');
    const m = /(?:sqrt\(|[\d(])(?:[\d\s.+\-*/^()%]|sqrt)*/.exec(s);
    if (!m) return null;
    const e = m[0].replace(/\s+/g, '');
    if (!/[+\-*/^%]|sqrt/.test(e)) return null;
    const v = calc(e);
    return v == null || !isFinite(v) ? null : v;
  }

  /* ---------- duração e datas ---------- */
  const UNIT_MS = { segundo: 1000, minuto: 60000, hora: 3600000 };
  function parseDuration(n) {
    const s = wordsToDigits(n).replace(/meia hora/g, '30 minutos').replace(/uma hora e meia/g, '90 minutos').replace(/(\d+) e meia hora/g, (_, h) => String(h * 60 + 30) + ' minutos');
    let total = 0, found = false;
    const re = /(\d+(?:[.,]\d+)?)\s*(segundos?|seg|minutos?|min|horas?|h)\b/g;
    let m;
    while ((m = re.exec(s))) {
      const v = parseFloat(m[1].replace(',', '.'));
      const u = m[2][0] === 's' ? 'segundo' : m[2][0] === 'm' ? 'minuto' : 'hora';
      total += v * UNIT_MS[u]; found = true;
    }
    return found ? total : 0;
  }
  function humanDur(ms) {
    const s = Math.round(ms / 1000);
    if (s < 60) return s + (s === 1 ? ' segundo' : ' segundos');
    const m = Math.floor(s / 60), r = s % 60;
    if (m < 60) return m + (m === 1 ? ' minuto' : ' minutos') + (r ? ' e ' + r + ' s' : '');
    const h = Math.floor(m / 60), mm = m % 60;
    return h + (h === 1 ? ' hora' : ' horas') + (mm ? ' e ' + mm + ' min' : '');
  }
  const FESTAS = { natal: [11, 25], 'ano novo': [0, 1], 'dia dos namorados': [5, 12], tiradentes: [3, 21], 'independencia': [8, 7], 'dia das criancas': [9, 12], halloween: [9, 31] };
  function nextDate(day, month, year) {
    const now = new Date(); const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    let d = new Date(year || now.getFullYear(), month, day);
    if (!year && d < today) d = new Date(now.getFullYear() + 1, month, day);
    return d;
  }
  function daysUntil(n) {
    let target = null, label = '';
    for (const k of Object.keys(FESTAS)) if (n.includes(k)) { target = nextDate(FESTAS[k][1], FESTAS[k][0]); label = k; }
    const m = /(\d{1,2})\s*(?:\/|de)\s*(\d{1,2}|janeiro|fevereiro|marco|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)(?:\s*(?:\/|de)\s*(\d{4}))?/.exec(n);
    if (!target && m) {
      const MES = ['janeiro', 'fevereiro', 'marco', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
      const mon = /^\d+$/.test(m[2]) ? parseInt(m[2], 10) - 1 : MES.indexOf(m[2]);
      const day = parseInt(m[1], 10);
      if (mon < 0 || mon > 11 || day < 1 || day > 31) return null;
      target = nextDate(day, mon, m[3] ? parseInt(m[3], 10) : 0);
      label = pad(day) + '/' + pad(mon + 1) + (m[3] ? '/' + m[3] : '');
    }
    if (!target) return null;
    const now = new Date(); const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const d = Math.round((target - today) / 86400000);
    if (d === 0) return 'É hoje.';
    if (d < 0) return 'Essa data foi há ' + (-d) + (d === -1 ? ' dia.' : ' dias.');
    return d === 1 ? 'Falta 1 dia para ' + label + '.' : 'Faltam ' + d + ' dias para ' + label + '.';
  }

  /* ---------- conversões ---------- */
  function convert(n) {
    const s = wordsToDigits(n).replace(/(\d),(\d)/g, '$1.$2');
    let m = /(-?\d+(?:\.\d+)?)\s*(?:km|quilometros?)\b.*\b(?:em|para|pra)\s+milhas?/.exec(s);
    if (m) return fmtNum(m[1] * 0.621371) + ' milhas.';
    m = /(-?\d+(?:\.\d+)?)\s*milhas?\b.*\b(?:em|para|pra)\s+(?:km|quilometros?)/.exec(s);
    if (m) return fmtNum(m[1] * 1.609344) + ' quilômetros.';
    m = /(-?\d+(?:\.\d+)?)\s*(?:kg|quilos?|quilogramas?)\b.*\b(?:em|para|pra)\s+(?:libras?|lb)/.exec(s);
    if (m) return fmtNum(m[1] * 2.204623) + ' libras.';
    m = /(-?\d+(?:\.\d+)?)\s*(?:libras?|lb)\b.*\b(?:em|para|pra)\s+(?:kg|quilos?)/.exec(s);
    if (m) return fmtNum(m[1] * 0.453592) + ' quilos.';
    m = /(-?\d+(?:\.\d+)?)\s*(?:graus?\s*)?(?:celsius|c)\b.*\b(?:em|para|pra)\s+(?:fahrenheit|f)\b/.exec(s);
    if (m) return fmtNum(m[1] * 9 / 5 + 32) + ' graus Fahrenheit.';
    m = /(-?\d+(?:\.\d+)?)\s*(?:graus?\s*)?(?:fahrenheit|f)\b.*\b(?:em|para|pra)\s+(?:celsius|c)\b/.exec(s);
    if (m) return fmtNum((m[1] - 32) * 5 / 9) + ' graus Celsius.';
    m = /(-?\d+(?:\.\d+)?)\s*(?:metros?|m)\b.*\b(?:em|para|pra)\s+(?:pes|ft)\b/.exec(s);
    if (m) return fmtNum(m[1] * 3.28084) + ' pés.';
    return null;
  }

  /* ---------- diário: busca simples por palavras ---------- */
  const STOP = new Set('a o as os um uma de do da dos das em no na nos nas por para pra com sobre que eu meu minha meus minhas tem tenho algo alguma qualquer coisa anotei anotado nas nos memoria memorias diario procure procurar busque buscar ache achar encontre e ou ao aos se foi era ser'.split(' '));
  function searchDiary(entries, q) {
    const words = norm(q).split(/[^a-z0-9]+/).filter((w) => w.length > 2 && !STOP.has(w));
    if (!words.length) return null;
    const scored = entries.map((e) => {
      const hay = norm((e.texto || '') + ' ' + (Array.isArray(e.tags) ? e.tags.join(' ') : ''));
      let sc = 0; words.forEach((w) => { if (hay.includes(w)) sc++; });
      return { e: e, sc: sc };
    }).filter((x) => x.sc > 0).sort((a, b) => b.sc - a.sc || (b.e.ts || 0) - (a.e.ts || 0));
    return scored.slice(0, 3).map((x) => x.e);
  }
  const cut = (t, n) => { t = String(t || '').replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n - 1) + '…' : t; };
  function when(ts) {
    const d = new Date(ts || Date.now());
    const today = new Date(); const y = new Date(); y.setDate(y.getDate() - 1);
    const same = (a, b) => a.toDateString() === b.toDateString();
    return same(d, today) ? 'hoje' : same(d, y) ? 'ontem' : pad(d.getDate()) + '/' + pad(d.getMonth() + 1);
  }

  /* ---------- fábrica ---------- */
  function create(api) {
    const reminders = []; // { id, at, text, timer }
    let pending = null;   // próxima mensagem tem destino especial (ex.: texto de uma anotação)
    let seq = 0;

    function addReminder(ms, text) {
      const id = ++seq; const at = Date.now() + ms;
      const timer = setTimeout(() => {
        const i = reminders.findIndex((r) => r.id === id); if (i >= 0) reminders.splice(i, 1);
        api.notify(text ? 'Lembrete: ' + text + '.' : 'Seu tempo acabou.');
      }, ms);
      reminders.push({ id: id, at: at, text: text, timer: timer });
    }
    function listReminders() {
      if (!reminders.length) return 'Não há lembretes ativos.';
      return reminders.slice().sort((a, b) => a.at - b.at).map((r) => 'Em ' + humanDur(Math.max(0, r.at - Date.now())) + (r.text ? ': ' + r.text : ': timer')).join('. ') + '.';
    }
    function clearReminders() { const n = reminders.length; reminders.forEach((r) => clearTimeout(r.timer)); reminders.length = 0; return n; }

    const HELP = 'Posso guardar e procurar suas memórias, dizer hora e data, calcular, converter unidades, contar dias até uma data, criar timers e lembretes, sortear números e lembrar o seu nome. ' +
      'Também faço o resumo do dia (música, notícias, agenda e e-mails importantes), toco e controlo o Spotify. Bata duas palmas para começar. ' +
      'Experimente: “resumo do dia”, “toque Legião Urbana”, “quais minhas reuniões”, “anote que amanhã tenho reunião”, “me lembre em 10 minutos de tomar água”.';

    async function reply(text) {
      const raw = String(text || '').trim();
      const n = norm(raw).replace(/[?!]+$/g, '').trim();
      if (!n) return null;

      if (pending === 'note') {
        pending = null;
        if (/^(cancela|cancelar|deixa|esquece|nada)\b/.test(n)) return 'Tudo bem, não anotei nada.';
        return save(raw, 'texto');
      }

      if (/\b(dorme|dormir|tchau|ate logo|encerrar|desativar|silencio)\b/.test(n)) { api.sleep(); return 'Até logo. Me chame quando precisar.'; }

      /* nome */
      let m = /\b(?:me chame de|pode me chamar de|meu nome e|me chamo)\s+([a-z' -]{2,30})$/.exec(n);
      if (m) {
        const nome = raw.slice(raw.toLowerCase().lastIndexOf(m[1].split(' ')[0])).trim().replace(/[.!]+$/, '');
        const clean = nome.replace(/^./, (c) => c.toUpperCase());
        api.setName(clean);
        return 'Prazer, ' + clean + '. Vou chamar você assim.';
      }
      if (/\b(qual (e )?meu nome|como (voce )?me chama)/.test(n)) { const nm = api.getName(); return nm ? 'Você é ' + nm + '.' : 'Ainda não sei. Diga “me chame de” e o seu nome.'; }

      /* hora e data */
      if (/\bque horas\b|\bhoras sao\b|\bhora certa\b|\bme (?:diga|fala|fale) as horas\b/.test(n)) {
        const d = new Date(), h = d.getHours(), mi = d.getMinutes();
        return (h === 1 ? 'É 1 hora' : 'São ' + h + ' horas') + (mi === 0 ? ' em ponto.' : ' e ' + mi + (mi === 1 ? ' minuto.' : ' minutos.'));
      }
      if (/\bque dia (e )?hoje\b|\bdata de hoje\b|\bdia da semana\b|\bem que dia estamos\b/.test(n)) {
        return 'Hoje é ' + new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }) + '.';
      }
      if (/\bquantos dias\b.*\b(faltam|falta|restam|para)\b|\bfaltam quantos dias\b/.test(n)) {
        const r = daysUntil(n); if (r) return r;
      }

      /* lembretes e timers */
      if (/\b(cancel\w+|apag\w+|limp\w+|remov\w+)\b.*\b(lembretes?|timers?|alarmes?)\b/.test(n)) { const c = clearReminders(); return c ? 'Cancelei ' + c + (c === 1 ? ' lembrete.' : ' lembretes.') : 'Não havia nada para cancelar.'; }
      if (/\b(quais|meus|tenho|listar|liste|ver)\b.*\b(lembretes?|timers?|alarmes?)\b/.test(n)) return listReminders();
      m = /\b(?:me lembre|me lembra|lembre-me|lembrar-me|me avise|me avisa|avise-me)\b\s*(?:daqui a|em|dentro de)?\s*(.*)/.exec(n);
      const isTimer = /\b(?:timer|cronometro|alarme|temporizador)\b/.test(n);
      if (m || isTimer) {
        const ms = parseDuration(n);
        if (ms >= 1000 && ms <= 24 * 3600000) {
          let what = '';
          const w = /\b(?:de|para|pra|que)\s+(.+?)(?:\s+(?:daqui a|em|dentro de)\s+\d.*)?$/.exec(m ? m[1].replace(/^\d+(?:[.,]\d+)?\s*(?:segundos?|seg|minutos?|min|horas?|h)\b(?:\s*e\s*\d+\s*(?:segundos?|minutos?|min))?\s*/, '') : '');
          if (m) what = (w ? w[1] : m[1].replace(/^\d+(?:[.,]\d+)?\s*(?:segundos?|seg|minutos?|min|horas?|h)\b\s*(?:de|para|pra|que)?\s*/, '')).trim();
          if (/^\d/.test(what) || what.length < 2) what = '';
          else { const at = n.lastIndexOf(what); if (at >= 0) what = raw.substr(at, what.length); }
          addReminder(ms, what);
          return 'Combinado. Aviso em ' + humanDur(ms) + (what ? ' para ' + what : '') + '. Deixe esta aba aberta até lá.';
        }
        if (m || isTimer) return 'Em quanto tempo? Diga, por exemplo, “me lembre em 10 minutos de tomar água”.';
      }

      /* diário */
      m = /^(?:anota|anote|anotar|guarda|guarde|guardar|registra|registre|registrar|lembra|lembre)(?:-me|\s+me)?\b\s*(?:que|de|isso|ai|aqui)?\s*(.*)$/.exec(n);
      if (m && !/\blembre\b.*\b(minuto|hora|segundo)/.test(n)) {
        let body = raw.replace(/^(anota|anote|anotar|guarda|guarde|guardar|registra|registre|registrar|lembra|lembre)(?:-me|\s+me)?\s*/i, '').replace(/^(que|de|isso|aí|ai|aqui)\s+/i, '').trim();
        if (!body) { pending = 'note'; return 'O que devo anotar?'; }
        return save(body, 'voz');
      }
      if (/\b(quero|vou|preciso|gostaria de)\b.*\banotar\b|\bnova (memoria|anotacao)\b/.test(n)) { pending = 'note'; return 'Pode falar. O que devo anotar?'; }

      if (/\bquantas (memorias|anotacoes)\b/.test(n)) { const c = api.entries().length; return c === 0 ? 'Seu diário está vazio.' : 'Você tem ' + c + (c === 1 ? ' memória guardada.' : ' memórias guardadas.'); }
      m = /\b(?:o que|oque)\s+(?:eu\s+)?anotei\s+(?:sobre|de|do|da|em)\s+(.+)|\b(?:procure|procurar|busque|buscar|ache|encontre|pesquise)\b.*?\b(?:sobre|por)\s+(.+)|\btenho (?:algo|alguma coisa|anotacao|memoria)\s+(?:sobre|de)\s+(.+)/.exec(n);
      if (m) {
        if (api.locked()) return 'Entre com sua conta Google para eu acessar o diário.';
        const q = m[1] || m[2] || m[3];
        const hits = searchDiary(api.entries(), q);
        if (!hits) return 'Não encontrei nada no diário sobre isso.';
        return (hits.length === 1 ? 'Encontrei uma anotação: ' : 'Encontrei ' + hits.length + ' anotações: ') + hits.map((e) => when(e.ts) + ', ' + cut(e.texto, 160)).join('. Depois: ') + '.';
      }
      if (/(le|ler|leia|mostra|mostre|fala|fale|diz|diga|quais|resuma|resumo).{0,25}(memorias|anotacoes|diario)|o que (eu )?anotei|ultimas (memorias|anotacoes)/.test(n)) {
        if (api.locked()) return 'Entre com sua conta Google para eu acessar o diário.';
        const top = api.entries().slice(0, 3);
        if (!top.length) return 'Seu diário está vazio.';
        return 'Suas últimas anotações: ' + top.map((e) => when(e.ts) + ', ' + cut(e.texto, 160)).join('. Depois: ') + '.';
      }
      if (/(abrir|abre|mostrar|mostre).{0,15}(memorias|diario)/.test(n)) { api.openTab('mem'); return 'Abrindo suas memórias.'; }
      if (/(voltar|volta|abrir|abre|mostrar|mostre).{0,15}(conversa|chat)/.test(n)) { api.openTab('chat'); return 'Certo.'; }
      if (/(mostr\w+|ver|rever|repet\w+).{0,12}abertura/.test(n)) { api.replayIntro(); return 'Reiniciando a abertura.'; }

      /* integrações: Spotify, Gmail, Agenda, notícias e resumo do dia (ver hub.js) */
      if (api.hub) { const hr = await api.hub.handle(n, raw); if (hr != null) return hr; }

      /* sorteios */
      if (/\bcara ou coroa\b/.test(n)) return pick(['Deu cara.', 'Deu coroa.']);
      m = /\b(?:jogue|jogar|role|rolar|lance)\b.*\bdado\b/.exec(n);
      if (m) { const f = /\bd(\d{1,3})\b/.exec(n); const k = f ? Math.max(2, +f[1]) : 6; return 'Saiu ' + (1 + Math.floor(Math.random() * k)) + '.'; }
      m = /\b(?:sorteie|sortear|sorteio|escolha)\b.*?\bentre\s+(\d+)\s+e\s+(\d+)|\bnumero\b.*\bentre\s+(\d+)\s+e\s+(\d+)/.exec(wordsToDigits(n));
      if (m) {
        const a = +(m[1] || m[3]), b = +(m[2] || m[4]); const lo = Math.min(a, b), hi = Math.max(a, b);
        return 'Sorteei ' + (lo + Math.floor(Math.random() * (hi - lo + 1))) + '.';
      }

      /* conversões e cálculo */
      const cv = convert(n);
      if (cv) return cv;
      if (/\b(quanto (e|da|fica|vale)|calcul\w+|resultado de|conta de|quanto sao|raiz)\b|\d\s*[+\-*/x^]\s*\d|\d\s*%|\bpor cento\b|\bmais\b.*\d|\bvezes\b/.test(wordsToDigits(n))) {
        const v = mathFrom(n);
        if (v != null) return 'O resultado é ' + fmtNum(v) + '.';
      }

      /* conversa */
      if (/^(oi|ola|e ai|opa|bom dia|boa tarde|boa noite|hey|salve|fala)( fhinix)?$/.test(n)) return api.greeting();
      if (/\b(obrigad[oa]|valeu|brigado)\b/.test(n)) return pick(['Disponha.', 'Sempre às ordens.', 'Por nada.']);
      if (/\b(o que (voce )?(sabe|pode|consegue) fazer|ajuda|comandos|como (te )?uso|funcoes)\b/.test(n)) return HELP;
      if (/\bquem (e )?(voce|tu)\b|\bo que (e )?(voce|tu)\b|\bse apresente\b/.test(n)) return 'Sou o Fhinix, seu assistente pessoal e diário. Rodo inteiramente neste navegador, sem depender de servidor externo.';
      if (/\bcomo (voce )?(esta|vai)\b|\btudo bem\b/.test(n)) return 'Funcionando perfeitamente. E com você?';
      if (/\b(quem (te )?(criou|fez|programou))\b/.test(n)) return 'Fui construído por você, com a ajuda do Claude, para ser o seu assistente.';
      return null;
    }

    async function save(body, origem) {
      try { await api.save(body, origem); return 'Anotado.'; }
      catch (e) { return e && e.message === 'locked' ? 'Entre com sua conta Google para eu guardar no diário.' : 'Não consegui guardar agora.'; }
    }

    return { reply: reply, help: HELP, activeReminders: () => reminders.length };
  }

  /* ---------- IA de linguagem local (opcional) ---------- */
  const WEBLLM_URL = 'https://cdn.jsdelivr.net/npm/@mlc-ai/web-llm@0.2.79/+esm';
  const DEFAULT_MODEL = 'Qwen2.5-1.5B-Instruct-q4f16_1-MLC';

  function createLLM(opts) {
    opts = opts || {};
    const modelId = opts.model || DEFAULT_MODEL;
    let engine = null, loading = null, state = 'off'; // off | loading | ready | error | unsupported

    const supported = () => !!(navigator.gpu);
    function load(onProgress) {
      if (engine) return Promise.resolve(engine);
      if (loading) return loading;
      if (!supported()) { state = 'unsupported'; return Promise.reject(new Error('webgpu')); }
      state = 'loading';
      loading = import(WEBLLM_URL)
        .then((web) => web.CreateMLCEngine(modelId, {
          initProgressCallback: (p) => { if (onProgress) onProgress(Math.max(0, Math.min(1, p.progress || 0)), p.text || ''); }
        }))
        .then((e) => { engine = e; state = 'ready'; return e; })
        .catch((err) => { state = 'error'; loading = null; throw err; });
      return loading;
    }
    async function ask(messages, onToken, shouldStop) {
      const e = await load();
      const stream = await e.chat.completions.create({ messages: messages, stream: true, temperature: 0.6, top_p: 0.9, max_tokens: 380 });
      let out = '';
      for await (const chunk of stream) {
        if (shouldStop && shouldStop()) { try { e.interruptGenerate(); } catch (_) { /* ignore */ } break; }
        const d = chunk.choices && chunk.choices[0] && chunk.choices[0].delta && chunk.choices[0].delta.content;
        if (d) { out += d; if (onToken) onToken(out); }
      }
      return out.trim();
    }
    return { load: load, ask: ask, supported: supported, get state() { return state; }, modelId: modelId };
  }

  window.FhinixBrain = { create: create, createLLM: createLLM, _test: { calc: calc, mathFrom: mathFrom, parseDuration: parseDuration, daysUntil: daysUntil, convert: convert, searchDiary: searchDiary, wordsToDigits: wordsToDigits } };
})();
