/* Fhinix · hub de integrações.
 * Palmas (detector de som) + Spotify + Gmail + Google Agenda + notícias + rotina "bom dia".
 * Tudo roda no navegador. Nada daqui é enviado a servidor próprio: os dados vão só para Google, Spotify e o leitor de RSS.
 */
(function () {
  'use strict';

  const norm = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  const pad = (n) => String(n).padStart(2, '0');
  const cut = (t, n) => { t = String(t || '').replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n - 1) + '…' : t; };
  const plural = (n, s, p) => (n === 1 ? s : p);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const ORD = ['Primeira', 'Segunda', 'Terceira', 'Quarta', 'Quinta', 'Sexta', 'Sétima', 'Oitava', 'Nona', 'Décima'];

  function spokenTime(d) {
    const h = d.getHours(), m = d.getMinutes();
    return m ? h + ' e ' + m : h + (h === 1 ? ' hora' : ' horas');
  }
  function greetWord() { const h = new Date().getHours(); return h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite'; }

  /* =====================================================================
   *  Detector de palmas (puro: recebe o nível de som e o tempo; fácil de testar)
   * ===================================================================== */
  class ClapDetector {
    constructor(o) { this.o = null; this.set(o); this.reset(); }
    set(o) {
      this.o = Object.assign({ ratio: 7, minRms: 0.03, maxClapMs: 220, minGap: 80, groupGap: 650, count: 2, cooldown: 3500 }, this.o || {}, o || {});
    }
    reset() { this.floor = 0.004; this.inSpike = false; this.t0 = 0; this.lastEnd = -1e9; this.claps = []; this.coolUntil = 0; }
    threshold() { return Math.max(this.o.minRms, this.floor * this.o.ratio); }
    /* rms: energia do trecho (já filtrada para agudos); t: milissegundos. Retorna 'clap', 'trigger' ou null. */
    feed(rms, t) {
      const o = this.o;
      let ev = null;
      const thr = this.threshold();
      if (!this.inSpike) {
        if (rms > thr && t - this.lastEnd >= o.minGap) { this.inSpike = true; this.t0 = t; }
        else this.floor += (rms - this.floor) * (rms > this.floor ? 0.004 : 0.03);
      } else if (rms < thr * 0.5) {
        this.inSpike = false;
        this.lastEnd = t;
        if (t - this.t0 <= o.maxClapMs) { this.claps.push(this.t0); ev = 'clap'; }
        else this.claps.length = 0; // som longo (fala, música): não é palma
      } else if (t - this.t0 > o.maxClapMs) {
        this.floor += (rms - this.floor) * 0.05; // ruído sustentado: se adapta
      }
      if (this.claps.length && !this.inSpike && t - this.claps[this.claps.length - 1] > o.groupGap) {
        const n = this.claps.length;
        this.claps.length = 0;
        if (n === o.count && t >= this.coolUntil) { this.coolUntil = t + o.cooldown; return 'trigger'; }
      }
      return ev;
    }
  }
  const fromSens = (s) => { s = Math.max(1, Math.min(10, +s || 5)); return { ratio: 12 - s, minRms: 0.055 - s * 0.005 }; };

  /* Captura do microfone: AudioWorklet (não sofre throttling em aba oculta) com plano B em ScriptProcessor. */
  const WORKLET = "class P extends AudioWorkletProcessor{constructor(){super();this.a=0;this.n=0;this.x=0;this.y=0;}" +
    "process(i){const c=i[0]&&i[0][0];if(!c)return true;for(let k=0;k<c.length;k++){const x=c[k];const y=0.88*(this.y+x-this.x);this.x=x;this.y=y;this.a+=y*y;}" +
    "this.n+=c.length;if(this.n>=480){this.port.postMessage(Math.sqrt(this.a/this.n));this.a=0;this.n=0;}return true;}}registerProcessor('fhinix-clap',P);";

  async function openMic(onRms) {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw new Error('nomic');
    const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } });
    const AC = window.AudioContext || window.webkitAudioContext;
    const ac = new AC();
    try { await ac.resume(); } catch (_) { /* ignore */ }
    const src = ac.createMediaStreamSource(stream);
    const mute = ac.createGain(); mute.gain.value = 0; mute.connect(ac.destination);
    let node = null;
    try {
      const url = URL.createObjectURL(new Blob([WORKLET], { type: 'application/javascript' }));
      await ac.audioWorklet.addModule(url);
      URL.revokeObjectURL(url);
      node = new AudioWorkletNode(ac, 'fhinix-clap');
      node.port.onmessage = (e) => onRms(e.data, performance.now());
    } catch (_) {
      node = ac.createScriptProcessor(512, 1, 1);
      let x1 = 0, y1 = 0, acc = 0, cnt = 0;
      node.onaudioprocess = (e) => {
        const c = e.inputBuffer.getChannelData(0);
        for (let k = 0; k < c.length; k++) { const x = c[k]; const y = 0.88 * (y1 + x - x1); x1 = x; y1 = y; acc += y * y; }
        cnt += c.length;
        if (cnt >= 480) { onRms(Math.sqrt(acc / cnt), performance.now()); acc = 0; cnt = 0; }
      };
    }
    src.connect(node); node.connect(mute);
    return {
      close() {
        try { node.disconnect(); src.disconnect(); } catch (_) { /* ignore */ }
        stream.getTracks().forEach((t) => t.stop());
        try { ac.close(); } catch (_) { /* ignore */ }
      }
    };
  }

  /* =====================================================================
   *  Triagem de e-mails (pura)
   * ===================================================================== */
  const STRONG = /\b(urgente|prazo|vence|vencimento|vencer|vencida|fatura|boleto|pagamento|cobranca|entrevista|contrato|seguranca|intimacao|multa|cancelamento|atrasad[oa])\b/;
  const WEAK = /\b(importante|reuniao|convite|proposta|agendad[oa]|confirmacao|confirmad[oa]|acesso|nota fiscal|pedido|entrega|passagem|voo|embarque|consulta|exame|resultado|documento|assinatura|renovacao|atencao|aviso|compromisso|aprovad[oa]|pendente|responda|resposta|orcamento)\b/;
  const NEG = /\b(oferta|ofertas|promocao|promocoes|desconto|descontos|cupom|liquidacao|black friday|frete gratis|ganhe|compre|aproveite|imperdivel|so hoje|ultimas horas|newsletter|novidades|lancamento|resumo semanal|digest|boletim|descubra|confira|sorteio|cashback)\b|% ?off|\d+ ?% de desconto/;
  const OTP = /(codigo|code).{0,20}(verifica|seguranca|acesso|login|confirmacao)|\botp\b|verification code|senha de uso unico/;
  const NOREPLY = /no-?reply|nao-?responda|do-?not-?reply|donotreply|mailer|newsletter|notifications?@|notificacoes?@|marketing|promo/;

  function parseFrom(h) {
    const m = /^\s*"?([^"<]*?)"?\s*<([^>]+)>\s*$/.exec(h || '');
    const email = (m ? m[2] : (h || '')).trim().toLowerCase();
    let name = m ? m[1].trim() : '';
    if (!name) name = email.split('@')[0].replace(/[._-]+/g, ' ');
    return { name: name, email: email };
  }
  function normMsg(g) {
    const H = {};
    ((g.payload && g.payload.headers) || []).forEach((h) => { H[String(h.name).toLowerCase()] = h.value; });
    const f = parseFrom(H.from);
    return {
      id: g.id, labels: g.labelIds || [], from: f.name, email: f.email,
      subject: H.subject || '(sem assunto)', snippet: g.snippet || '',
      unsub: !!H['list-unsubscribe'], ts: +g.internalDate || Date.parse(H.date) || 0
    };
  }
  /* Nota de importância. Mantém quem passa de notaMin; o resto é descartado da leitura (nada é apagado do Gmail). */
  function scoreEmail(m, cfg) {
    cfg = cfg || {};
    const L = new Set(m.labels || []);
    const text = norm(m.subject + ' ' + String(m.snippet || '').slice(0, 160));
    const who = norm(m.from + ' ' + m.email);
    let s = 0;
    if ((cfg.bloquear || []).some((b) => who.includes(norm(b)))) return { score: -99, drop: 'bloqueado' };
    if (OTP.test(text)) return { score: -50, drop: 'codigo' }; // códigos de verificação não são lidos em voz alta
    if ((cfg.vips || []).some((v) => who.includes(norm(v)))) s += 6;
    if (L.has('IMPORTANT')) s += 3;
    if (L.has('STARRED')) s += 3;
    if (L.has('CATEGORY_PERSONAL')) s += 3;
    if (L.has('CATEGORY_PROMOTIONS')) s -= 6;
    if (L.has('CATEGORY_SOCIAL')) s -= 4;
    if (L.has('CATEGORY_FORUMS')) s -= 3;
    if (m.unsub) s -= 2;
    if (NOREPLY.test(m.email)) s -= 1;
    if (STRONG.test(text)) s += 4; else if (WEAK.test(text)) s += 2;
    if (NEG.test(text)) s -= 3;
    return { score: s, drop: null };
  }
  function triage(msgs, cfg) {
    const min = (cfg && cfg.notaMin) != null ? cfg.notaMin : 3;
    const scored = msgs.map((m) => Object.assign({}, m, scoreEmail(m, cfg)));
    const keep = scored.filter((m) => !m.drop && m.score >= min).sort((a, b) => b.score - a.score || b.ts - a.ts);
    return { keep: keep, dropped: scored.length - keep.length, total: scored.length };
  }
  const cleanSubject = (s) => cut(String(s || '').replace(/^\s*((re|fwd?|enc|res)\s*:\s*)+/i, '').replace(/[^\p{L}\p{N}\s.,:;!?%$@()/\-]/gu, ' '), 100);

  /* =====================================================================
   *  Notícias (RSS via leitor com CORS liberado; sem chave)
   * ===================================================================== */
  const DEFAULT_FEEDS = [
    'https://news.google.com/rss?hl=pt-BR&gl=BR&ceid=BR:pt-419',
    'https://g1.globo.com/rss/g1/'
  ];
  function splitTitle(raw) {
    const t = String(raw || '').replace(/\s+/g, ' ').trim();
    const i = t.lastIndexOf(' - ');
    if (i > 20 && t.length - i < 40) return { title: t.slice(0, i), source: t.slice(i + 3) };
    return { title: t, source: '' };
  }
  const safeUrl = (u) => { try { const x = new URL(u); return /^https?:$/.test(x.protocol) ? x.href : ''; } catch (_) { return ''; } };
  async function fetchJson(url, ms) {
    const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), ms || 9000);
    try { const r = await fetch(url, { signal: ctl.signal }); if (!r.ok) throw new Error('http' + r.status); return await r.json(); }
    finally { clearTimeout(to); }
  }
  async function fetchText(url, ms) {
    const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), ms || 9000);
    try { const r = await fetch(url, { signal: ctl.signal }); if (!r.ok) throw new Error('http' + r.status); return await r.text(); }
    finally { clearTimeout(to); }
  }
  async function readFeed(url) {
    try {
      const j = await fetchJson('https://api.rss2json.com/v1/api.json?rss_url=' + encodeURIComponent(url));
      if (j && j.status === 'ok' && Array.isArray(j.items) && j.items.length) return j.items.map((i) => ({ raw: i.title, link: i.link, ts: Date.parse(i.pubDate) || 0 }));
    } catch (_) { /* tenta o plano B */ }
    const xml = await fetchText('https://api.allorigins.win/raw?url=' + encodeURIComponent(url));
    const doc = new DOMParser().parseFromString(xml, 'text/xml');
    return Array.prototype.map.call(doc.querySelectorAll('item'), (it) => ({
      raw: (it.querySelector('title') || {}).textContent, link: (it.querySelector('link') || {}).textContent,
      ts: Date.parse((it.querySelector('pubDate') || {}).textContent) || 0
    }));
  }
  async function fetchNews(cfg) {
    const feeds = (cfg && cfg.feeds && cfg.feeds.length ? cfg.feeds : DEFAULT_FEEDS);
    const max = (cfg && cfg.max) || 5;
    const res = await Promise.allSettled(feeds.map(readFeed));
    const lists = res.filter((r) => r.status === 'fulfilled' && r.value.length).map((r) => r.value);
    if (!lists.length) throw new Error('news');
    const out = [], seen = new Set();
    for (let i = 0; out.length < max && i < 30; i++) {
      let any = false;
      for (let k = 0; k < lists.length && out.length < max; k++) {
        const it = lists[k][i]; if (!it) continue; any = true;
        const p = splitTitle(it.raw);
        const key = norm(p.title).slice(0, 40);
        if (!p.title || seen.has(key)) continue;
        seen.add(key); out.push({ title: p.title, source: p.source, link: safeUrl(it.link) });
      }
      if (!any) break;
    }
    return out;
  }
  function newsText(items) {
    if (!items.length) return 'Não achei notícias agora.';
    return 'Principais notícias. ' + items.map((n, i) => ORD[i] + ': ' + n.title + '.').join(' ');
  }

  /* =====================================================================
   *  Spotify (PKCE no navegador; sem segredo no código)
   * ===================================================================== */
  function createSpotify(scfg, api) {
    const CID = scfg.clientId;
    const configured = !!(CID && !/^COLE/i.test(CID));
    const KEY = 'fhinix.spotify', KEYP = 'fhinix.spotify.pkce';
    const SCOPES = 'streaming user-read-email user-read-private user-read-playback-state user-modify-playback-state user-read-currently-playing';
    let tok = null, player = null, webId = null, lastErr = '';
    try { tok = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (_) { tok = null; }
    const redirect = () => location.origin + location.pathname;
    const save = (t) => { tok = t; try { if (t) localStorage.setItem(KEY, JSON.stringify(t)); else localStorage.removeItem(KEY); } catch (_) { /* ignore */ } };
    const b64 = (buf) => btoa(String.fromCharCode.apply(null, new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    const rand = (n) => b64(crypto.getRandomValues(new Uint8Array(n)));

    async function connect() {
      if (!configured) throw new Error('noclient');
      const verifier = rand(48), state = rand(12);
      const challenge = b64(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier)));
      try { localStorage.setItem(KEYP, JSON.stringify({ v: verifier, s: state })); } catch (_) { /* ignore */ }
      const q = new URLSearchParams({ client_id: CID, response_type: 'code', redirect_uri: redirect(), scope: SCOPES, code_challenge_method: 'S256', code_challenge: challenge, state: state });
      location.href = 'https://accounts.spotify.com/authorize?' + q.toString();
    }
    async function tokenReq(params) {
      const r = await fetch('https://accounts.spotify.com/api/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(params) });
      const j = await r.json();
      if (!r.ok || !j.access_token) throw new Error(j.error_description || j.error || 'token');
      return j;
    }
    async function handleRedirect() {
      const p = new URLSearchParams(location.search);
      if (!p.has('code') && !p.has('error')) return;
      let pk = null;
      try { pk = JSON.parse(localStorage.getItem(KEYP) || 'null'); localStorage.removeItem(KEYP); } catch (_) { pk = null; }
      if (!pk || p.get('state') !== pk.s) return; // não é um retorno do Spotify iniciado por este app
      history.replaceState({}, '', location.pathname);
      if (p.has('error')) { api.addMsg('sys', 'O Spotify não foi autorizado (' + p.get('error') + ').'); return; }
      try {
        const j = await tokenReq({ client_id: CID, grant_type: 'authorization_code', code: p.get('code'), redirect_uri: redirect(), code_verifier: pk.v });
        save({ access: j.access_token, refresh: j.refresh_token, exp: Date.now() + j.expires_in * 1000 });
        api.addMsg('sys', 'Spotify conectado.');
      } catch (e) { api.addMsg('sys', 'Não consegui concluir a conexão com o Spotify.'); }
    }
    async function token() {
      if (!tok) throw Object.assign(new Error('auth'), { spotify: true });
      if (tok.exp - 60000 > Date.now()) return tok.access;
      try {
        const j = await tokenReq({ client_id: CID, grant_type: 'refresh_token', refresh_token: tok.refresh });
        save({ access: j.access_token, refresh: j.refresh_token || tok.refresh, exp: Date.now() + j.expires_in * 1000 });
        return tok.access;
      } catch (_) { save(null); throw Object.assign(new Error('auth'), { spotify: true }); }
    }
    async function call(method, path, body, query) {
      const url = 'https://api.spotify.com/v1' + path + (query ? '?' + new URLSearchParams(query).toString() : '');
      const r = await fetch(url, { method: method, headers: { Authorization: 'Bearer ' + (await token()), 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
      if (r.status === 204 || r.status === 202) return null;
      let j = null; try { j = await r.json(); } catch (_) { /* sem corpo */ }
      if (!r.ok) {
        const reason = (j && j.error && (j.error.reason || j.error.message)) || '';
        throw Object.assign(new Error(reason || 'http' + r.status), { status: r.status, reason: reason, spotify: true });
      }
      return j;
    }

    function loadSdk() {
      return new Promise((res, rej) => {
        if (window.Spotify) return res();
        window.onSpotifyWebPlaybackSDKReady = () => res();
        const s = document.createElement('script'); s.src = 'https://sdk.scdn.co/spotify-player.js'; s.onerror = () => rej(new Error('sdk'));
        document.head.appendChild(s);
      });
    }
    async function initPlayer() {
      if (player || !tok) return;
      try {
        await loadSdk();
        player = new window.Spotify.Player({ name: scfg.nomeDoAparelho || 'Fhinix', getOAuthToken: (cb) => { token().then(cb).catch(() => {}); }, volume: 0.7 });
        player.addListener('ready', (d) => { webId = d.device_id; });
        player.addListener('not_ready', () => { webId = null; });
        player.addListener('account_error', () => { lastErr = 'premium'; api.addMsg('sys', 'O player do navegador exige Spotify Premium. Ainda dá para controlar o app do Spotify aberto em outro aparelho.'); });
        player.addListener('initialization_error', () => { lastErr = 'init'; });
        player.addListener('authentication_error', () => { lastErr = 'auth'; });
        player.addListener('autoplay_failed', () => { api.addMsg('sys', 'O navegador bloqueou o som automático. Toque uma vez na página e tente de novo.'); });
        await player.connect();
      } catch (_) { player = null; }
    }
    function prime() {
      if (!tok) return;
      initPlayer().then(() => { try { if (player && player.activateElement) player.activateElement(); } catch (_) { /* ignore */ } });
    }

    async function devices() { const j = await call('GET', '/me/player/devices'); return (j && j.devices) || []; }
    async function playOn(body) {
      try { await call('PUT', '/me/player/play', body); return; }
      catch (e) { if (e.status !== 404 && !/NO_ACTIVE_DEVICE/.test(e.reason || '')) throw e; }
      for (let i = 0; i < 6 && !webId; i++) { if (!player) break; await sleep(500); } // espera o player do navegador ficar pronto
      const list = await devices();
      const cand = [(list.find((d) => d.is_active) || {}).id, webId, (list[0] || {}).id].filter(Boolean);
      if (!cand.length) throw Object.assign(new Error('nodevice'), { spotify: true, nodevice: true });
      await call('PUT', '/me/player/play', body, { device_id: cand[0] });
    }
    const asUri = (s) => { const m = /open\.spotify\.com\/(playlist|album|artist)\/([A-Za-z0-9]+)/.exec(s || ''); return m ? 'spotify:' + m[1] + ':' + m[2] : (s || ''); };

    async function playConfig() {
      const uri = asUri(scfg.playlist);
      if (scfg.aleatorio !== false && uri) { try { await call('PUT', '/me/player/shuffle', null, { state: 'true' }); } catch (_) { /* sem aparelho ativo ainda */ } }
      await playOn(uri ? { context_uri: uri } : undefined);
    }
    async function search(q) {
      const hint = { playlist: /\bplaylist\b/.test(q), album: /\balbum\b/.test(q) };
      const qq = q.replace(/\b(a|o|as|os|um|uma|musica|cancao|playlist|album|do|da|de|banda|artista|no spotify|pra mim|para mim|ai)\b/g, ' ').replace(/\s+/g, ' ').trim() || q;
      const types = hint.playlist ? 'playlist' : hint.album ? 'album' : 'track,artist,playlist';
      const j = await call('GET', '/search', null, { q: qq, type: types, limit: '3' });
      const first = (k) => ((j[k] && j[k].items) || []).filter(Boolean)[0];
      const artist = first('artists'), track = first('tracks'), pl = first('playlists'), al = first('albums');
      if (hint.playlist && pl) return { name: pl.name, body: { context_uri: pl.uri } };
      if (hint.album && al) return { name: al.name, body: { context_uri: al.uri } };
      if (artist && (norm(artist.name).includes(norm(qq)) || norm(qq).includes(norm(artist.name))) && !track) return { name: artist.name, body: { context_uri: artist.uri } };
      if (track) return { name: track.name + ', de ' + track.artists.map((a) => a.name).join(' e '), body: { uris: [track.uri] } };
      if (artist) return { name: artist.name, body: { context_uri: artist.uri } };
      if (pl) return { name: pl.name, body: { context_uri: pl.uri } };
      return null;
    }
    async function playQuery(q) {
      const r = await search(q);
      if (!r) return null;
      await playOn(r.body);
      return r.name;
    }
    const state = () => call('GET', '/me/player');
    async function nowPlaying() {
      const j = await call('GET', '/me/player/currently-playing');
      if (!j || !j.item) return null;
      return { name: j.item.name, artists: (j.item.artists || []).map((a) => a.name).join(' e '), playing: !!j.is_playing };
    }
    const pause = () => call('PUT', '/me/player/pause').catch(() => {});
    const resume = () => playOn(undefined);
    const next = () => call('POST', '/me/player/next');
    const prev = () => call('POST', '/me/player/previous');
    const setVolume = (p) => call('PUT', '/me/player/volume', null, { volume_percent: String(Math.max(0, Math.min(100, Math.round(p)))) }).catch(() => {});
    async function changeVolume(delta) {
      const st = await state();
      const cur = st && st.device ? st.device.volume_percent : 50;
      const v = Math.max(0, Math.min(100, cur + delta));
      await call('PUT', '/me/player/volume', null, { volume_percent: String(v) });
      return v;
    }
    return {
      configured: configured, get connected() { return !!tok; }, get lastErr() { return lastErr; },
      connect: connect, disconnect: () => { save(null); if (player) { try { player.disconnect(); } catch (_) { /* ignore */ } player = null; } },
      handleRedirect: handleRedirect, prime: prime, playConfig: playConfig, playQuery: playQuery, nowPlaying: nowPlaying, state: state,
      pause: pause, resume: resume, next: next, prev: prev, setVolume: setVolume, changeVolume: changeVolume, _asUri: asUri
    };
  }

  /* =====================================================================
   *  Google (Gmail + Agenda), somente leitura, token do login do Firebase
   * ===================================================================== */
  function createGoogle(api, cfg) {
    async function gfetch(url) {
      const t = api.googleToken();
      if (!t) throw Object.assign(new Error('auth'), { auth: true });
      const r = await fetch(url, { headers: { Authorization: 'Bearer ' + t } });
      if (r.ok) return r.json();
      let msg = ''; try { msg = ((await r.json()).error || {}).message || ''; } catch (_) { /* ignore */ }
      if (r.status === 401) throw Object.assign(new Error('auth'), { auth: true });
      if (r.status === 403 && /has not been used|is disabled|accessNotConfigured/i.test(msg)) throw Object.assign(new Error('apioff'), { apiOff: true });
      if (r.status === 403) throw Object.assign(new Error('auth'), { auth: true, scope: true });
      throw new Error('http' + r.status);
    }
    async function emails() {
      const q = cfg.consultaGmail || 'is:unread in:inbox newer_than:2d';
      const list = await gfetch('https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=' + (cfg.analisar || 30) + '&q=' + encodeURIComponent(q));
      const ids = (list.messages || []).map((m) => m.id);
      const base = 'https://gmail.googleapis.com/gmail/v1/users/me/messages/';
      const got = await Promise.allSettled(ids.map((id) => gfetch(base + id + '?format=metadata&metadataHeaders=From&metadataHeaders=Subject&metadataHeaders=Date&metadataHeaders=List-Unsubscribe')));
      const msgs = got.filter((g) => g.status === 'fulfilled').map((g) => normMsg(g.value));
      return triage(msgs, cfg);
    }
    async function agenda() {
      const now = new Date();
      const eod = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0);
      const eot = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 2, 0, 0, 0);
      const url = 'https://www.googleapis.com/calendar/v3/calendars/primary/events?singleEvents=true&orderBy=startTime&maxResults=25&timeMin=' + encodeURIComponent(now.toISOString()) + '&timeMax=' + encodeURIComponent(eot.toISOString());
      const j = await gfetch(url);
      const evs = (j.items || []).filter((e) => e.status !== 'cancelled' && !((e.attendees || []).some((a) => a.self && a.responseStatus === 'declined'))).map((e) => {
        const allDay = !!(e.start && e.start.date && !e.start.dateTime);
        const start = new Date(e.start.dateTime || (e.start.date + 'T00:00:00'));
        const end = new Date(e.end && (e.end.dateTime || (e.end.date + 'T00:00:00')) || start);
        return { title: cut(e.summary || 'sem título', 90), start: start, end: end, allDay: allDay };
      }).filter((e) => e.allDay || e.end > now);
      return { hoje: evs.filter((e) => e.start < eod), amanha: evs.filter((e) => e.start >= eod) };
    }
    return { emails: emails, agenda: agenda };
  }
  function emailsText(r) {
    if (!r.keep.length) return 'Nenhum e-mail importante não lido nas últimas horas.' + (r.dropped ? ' Ignorei ' + r.dropped + ' ' + plural(r.dropped, 'automático ou promocional.', 'automáticos ou promocionais.') : '');
    const n = r.keep.length;
    return 'Você tem ' + n + ' ' + plural(n, 'e-mail importante.', 'e-mails importantes.') + ' ' +
      r.keep.map((m, i) => ORD[i] + ', de ' + cut(m.from, 40) + ': ' + cleanSubject(m.subject) + '.').join(' ') +
      (r.dropped ? ' Ignorei ' + r.dropped + ' ' + plural(r.dropped, 'automático ou promocional.', 'automáticos ou promocionais.') : '');
  }
  function agendaText(a) {
    const fmt = (e) => (e.allDay ? 'o dia todo, ' : 'às ' + spokenTime(e.start) + ', ') + e.title;
    const parts = [];
    if (a.hoje.length) {
      const first = a.hoje.find((e) => !e.allDay && e.start > new Date());
      const mins = first ? Math.round((first.start - Date.now()) / 60000) : null;
      if (mins != null && mins <= 60) parts.push('Atenção: seu próximo compromisso começa em ' + mins + ' ' + plural(mins, 'minuto.', 'minutos.'));
      parts.push('Hoje você tem ' + a.hoje.length + ' ' + plural(a.hoje.length, 'compromisso.', 'compromissos.') + ' ' + a.hoje.slice(0, 6).map((e) => fmt(e) + '.').join(' '));
    } else {
      parts.push('Você não tem mais compromissos hoje.');
    }
    if (a.amanha.length) parts.push('Amanhã: ' + a.amanha.slice(0, 3).map((e) => fmt(e) + '.').join(' '));
    return parts.join(' ');
  }

  /* =====================================================================
   *  Hub: painel, rotina e comandos de voz
   * ===================================================================== */
  function create(api) {
    const cfg = api.cfg || {};
    const sCfg = cfg.spotify || {}, pCfg = cfg.palmas || {}, rCfg = cfg.resumo || {}, nCfg = cfg.noticias || {};
    const sp = createSpotify(sCfg, api);
    const gg = createGoogle(api, rCfg);
    const SENS_KEY = 'fhinix.palmas.sens';
    let sens = +(function () { try { return localStorage.getItem(SENS_KEY); } catch (_) { return null; } })() || pCfg.sensibilidade || 5;
    const det = new ClapDetector(Object.assign({ count: pCfg.quantidade || 2 }, fromSens(sens)));
    let mic = null, running = false, aborted = false, clapCount = 0, lastUi = 0;
    const ui = {};

    /* ---------- painel ---------- */
    const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
    function btn(label, fn, cls) { const b = el('button', cls || 'sbtn', label); b.type = 'button'; b.addEventListener('click', fn); return b; }
    function build() {
      const root = api.root; if (!root) return;
      root.replaceChildren();
      const rows = el('div', 'hrows');
      const row = (name) => { const r = el('div', 'hrow'); const l = el('span', 'hl', name); const v = el('span', 'hv'); const a = el('span', 'ha'); r.append(l, v, a); rows.appendChild(r); return { v: v, a: a }; };
      ui.sp = row('Spotify'); ui.gg = row('Google'); ui.cl = row('Palmas');
      if (api.listVoices) {
        const vr = row('Voz'); ui.voz = el('select', 'hsel'); ui.voz.setAttribute('aria-label', 'Voz do Fhinix');
        const fill = () => { const L = api.listVoices(); ui.voz.replaceChildren(); L.forEach((n) => { const o = el('option', null, n); o.value = n; ui.voz.appendChild(o); }); if (!L.length) ui.voz.appendChild(el('option', null, 'padrão do navegador')); ui.voz.value = api.currentVoice(); };
        fill(); setTimeout(fill, 1500); setTimeout(fill, 4000); // as vozes do navegador carregam com atraso
        ui.voz.addEventListener('change', () => api.setVoice(ui.voz.value));
        vr.v.appendChild(ui.voz);
      }
      const meterWrap = el('div', 'hmeter'); ui.bar = el('div', 'hbar'); ui.mark = el('div', 'hmark'); meterWrap.append(ui.bar, ui.mark);
      const sensRow = el('label', 'hsens'); sensRow.append(el('span', null, 'Sensibilidade'));
      ui.sens = el('input'); ui.sens.type = 'range'; ui.sens.min = '1'; ui.sens.max = '10'; ui.sens.value = String(sens);
      ui.sens.addEventListener('input', () => { sens = +ui.sens.value; det.set(fromSens(sens)); try { localStorage.setItem(SENS_KEY, String(sens)); } catch (_) { /* ignore */ } });
      sensRow.appendChild(ui.sens);
      ui.count = el('div', 'hnote', '');
      const acts = el('div', 'hacts');
      acts.append(btn('Resumo agora', () => runRoutine(), 'sbtn'), btn('Parar', () => stop(), 'sbtn'));
      ui.cards = el('div', 'hcards');
      root.append(rows, meterWrap, sensRow, ui.count, acts, ui.cards);
      ['agenda', 'emails', 'noticias', 'musica'].forEach((k) => { ui['c_' + k] = el('section', 'hcard'); ui.cards.appendChild(ui['c_' + k]); });
      setCard('musica', 'Spotify', ['Nada tocando.']);
      setCard('agenda', 'Agenda', ['Ainda não consultei.']);
      setCard('emails', 'E-mails importantes', ['Ainda não consultei.']);
      setCard('noticias', 'Notícias', ['Ainda não consultei.']);
      refreshStatus();
    }
    function setCard(key, title, lines) {
      const c = ui['c_' + key]; if (!c) return;
      c.replaceChildren(el('h3', null, title));
      const ul = el('ul');
      lines.forEach((ln) => {
        const li = el('li');
        const o = typeof ln === 'string' ? { text: ln } : ln;
        if (o.href) { const a = el('a', null, o.text); a.href = o.href; a.target = '_blank'; a.rel = 'noopener noreferrer'; li.appendChild(a); }
        else li.appendChild(el('span', null, o.text));
        if (o.sub) li.appendChild(el('small', null, o.sub));
        ul.appendChild(li);
      });
      c.appendChild(ul);
    }
    function status(o, text, label, fn) {
      o.v.textContent = text; o.a.replaceChildren();
      if (label) o.a.appendChild(btn(label, fn));
    }
    function refreshStatus() {
      if (!ui.sp) return;
      if (!sp.configured) status(ui.sp, 'Falta o Client ID', '', null);
      else if (sp.connected) status(ui.sp, 'Conectado', 'Desconectar', () => { sp.disconnect(); refreshStatus(); });
      else status(ui.sp, 'Desconectado', 'Conectar', () => sp.connect().catch(() => api.addMsg('sys', 'Não consegui iniciar a conexão com o Spotify.')));
      if (!api.googleAvailable()) status(ui.gg, 'Indisponível (configure o Firebase)', '', null);
      else if (api.googleToken()) status(ui.gg, 'Conectado (Gmail + Agenda)', '', null);
      else status(ui.gg, 'Desconectado', 'Conectar Google', () => api.connectGoogle().then(refreshStatus).catch(() => api.addMsg('sys', 'Não consegui entrar com o Google agora.')));
      status(ui.cl, mic ? 'Ligadas (' + (pCfg.quantidade || 2) + ' palmas)' : 'Desligadas', mic ? 'Desligar' : 'Ligar', () => (mic ? stopClaps() : startClaps()));
    }

    /* ---------- palmas ---------- */
    function onRms(rms, t) {
      const ev = det.feed(rms, t);
      if (ev === 'clap') { clapCount++; if (ui.count) ui.count.textContent = 'Palmas ouvidas: ' + clapCount; }
      if (ui.bar && t - lastUi > 60 && !document.hidden) {
        lastUi = t;
        ui.bar.style.width = Math.min(100, rms / 0.2 * 100) + '%';
        ui.mark.style.left = Math.min(100, det.threshold() / 0.2 * 100) + '%';
      }
      if (ev === 'trigger' && !api.isSpeaking()) { api.onClapWake(); onDoubleClap(); }
    }
    async function startClaps() {
      if (mic) return true;
      try {
        det.reset();
        mic = await openMic(onRms);
        api.addMsg('sys', 'Palmas ligadas: bata ' + (pCfg.quantidade || 2) + ' palmas para ouvir o resumo e a música.');
        refreshStatus();
        return true;
      } catch (e) {
        mic = null; refreshStatus();
        api.addMsg('sys', 'Não consegui ouvir o microfone para as palmas. Libere o acesso nas permissões do site.');
        return false;
      }
    }
    function stopClaps() { if (mic) { mic.close(); mic = null; } refreshStatus(); }

    /* ---------- dados ---------- */
    function errText(e, what) {
      if (e && e.apiOff) return 'A API do ' + what + ' não está ativada no projeto do Google Cloud. O passo a passo está no LEIA-ME.';
      if (e && e.auth) return 'Para ler ' + (what === 'Gmail' ? 'seus e-mails' : 'sua agenda') + ' preciso da sua autorização do Google. Abra o Painel e toque em Conectar Google.';
      return 'Não consegui acessar ' + (what === 'Gmail' ? 'o Gmail' : what === 'notícias' ? 'as notícias' : 'a agenda') + ' agora.';
    }
    const safe = (p) => p.then((data) => ({ data: data }), (err) => ({ err: err }));
    const getNews = () => safe(fetchNews(nCfg));
    const getAgenda = () => safe(gg.agenda());
    const getEmails = () => safe(gg.emails());

    function paintNews(r) { setCard('noticias', 'Notícias', r.err ? [errText(r.err, 'notícias')] : r.data.map((n) => ({ text: n.title, sub: n.source, href: n.link }))); }
    function paintAgenda(r) {
      if (r.err) return setCard('agenda', 'Agenda', [errText(r.err, 'Agenda')]);
      const f = (e) => ({ text: e.title, sub: e.allDay ? 'o dia todo' : pad(e.start.getHours()) + ':' + pad(e.start.getMinutes()) });
      const L = r.data.hoje.map(f); if (!L.length) L.push('Nada mais hoje.');
      setCard('agenda', 'Agenda', L.concat(r.data.amanha.slice(0, 3).map((e) => { const x = f(e); x.sub = 'amanhã · ' + x.sub; return x; })));
    }
    function paintEmails(r) {
      if (r.err) return setCard('emails', 'E-mails importantes', [errText(r.err, 'Gmail')]);
      const L = r.data.keep.slice(0, rCfg.maxEmails || 5).map((m) => ({ text: cleanSubject(m.subject), sub: cut(m.from, 40) }));
      if (!L.length) L.push('Nenhum importante agora.');
      if (r.data.dropped) L.push({ text: r.data.dropped + ' ignorados (promoções e automáticos)', sub: 'nada foi apagado' });
      setCard('emails', 'E-mails importantes', L);
    }
    const emailsSpoken = (r) => emailsText({ keep: r.keep.slice(0, rCfg.maxEmails || 5), dropped: r.dropped });
    async function paintNow() {
      if (!sp.connected) return;
      try { const n = await sp.nowPlaying(); setCard('musica', 'Spotify', [n ? { text: n.name, sub: n.artists + (n.playing ? ' · tocando' : ' · pausado') } : 'Nada tocando.']); } catch (_) { /* ignore */ }
    }

    /* ---------- rotina ---------- */
    async function runRoutine() {
      if (running) return;
      running = true; aborted = false;
      const duck = sCfg.volumeFundo != null ? sCfg.volumeFundo : 30, back = sCfg.volume != null ? sCfg.volume : 70;
      let music = false;
      try {
        api.addMsg('sys', 'Rotina iniciada.');
        const jobs = { noticias: getNews(), agenda: getAgenda(), emails: getEmails() }; // busca tudo em paralelo
        if (sp.connected) {
          try { await sp.playConfig(); music = true; await sleep(700); await sp.setVolume(duck); paintNow(); }
          catch (e) { api.addMsg('sys', spErr(e)); }
        }
        await api.say(greetWord() + (api.userName() ? ', ' + api.userName() : '') + '. Aqui está o seu resumo.');
        const order = rCfg.ordem || ['noticias', 'agenda', 'emails'];
        for (let i = 0; i < order.length && !aborted; i++) {
          const k = order[i]; if (!jobs[k]) continue;
          const r = await jobs[k];
          let text;
          if (k === 'noticias') { paintNews(r); text = r.err ? errText(r.err, 'notícias') : newsText(r.data); }
          else if (k === 'agenda') { paintAgenda(r); text = r.err ? errText(r.err, 'Agenda') : agendaText(r.data); }
          else { paintEmails(r); text = r.err ? errText(r.err, 'Gmail') : emailsSpoken(r.data); }
          if (!aborted) await api.say(text);
        }
        if (!aborted) await api.say('Fim do resumo.');
      } finally {
        running = false;
        if (music) sp.setVolume(back);
      }
    }
    function stop() { aborted = true; api.stopSpeaking(); if (sp.connected) sp.setVolume(sCfg.volume != null ? sCfg.volume : 70); }
    async function onDoubleClap() {
      if (running) { stop(); return; }
      let playing = false;
      if (sp.connected && !rCfg.sempreResumo) { try { const st = await sp.state(); playing = !!(st && st.is_playing); } catch (_) { /* ignore */ } }
      if (playing) { await sp.pause(); api.addMsg('sys', 'Música pausada.'); paintNow(); }
      else runRoutine();
    }

    /* ---------- comandos de voz ---------- */
    function spErr(e) {
      if (e && e.spotify && !sp.connected) return 'O Spotify não está conectado. Abra o Painel e toque em Conectar.';
      if (e && e.nodevice) return 'Não achei nenhum aparelho com Spotify aberto. Abra o app do Spotify no celular ou no computador, ou use o Chrome com Premium.';
      if (e && (e.status === 403 || /PREMIUM/.test(e.reason || ''))) return 'O Spotify recusou o comando. Controlar a reprodução exige conta Premium.';
      return 'Não consegui falar com o Spotify agora.';
    }
    const needSp = () => (!sp.configured ? 'O Spotify ainda não foi configurado: falta o Client ID no firebase-config.js.' : !sp.connected ? 'O Spotify não está conectado. Abra o Painel e toque em Conectar.' : null);
    async function viaSp(fn) { const m = needSp(); if (m) return m; try { return await fn(); } catch (e) { return spErr(e); } }

    async function handle(n, raw) {
      let m;
      if (/^(pare|chega|cancela o resumo)\b|\b(pare|para) (o resumo|a leitura|de falar)\b/.test(n)) { stop(); return running ? 'Parando.' : 'Certo.'; }
      if (/\b(resumo do dia|resumo da manha|meu resumo|me de o resumo|briefing|me atualiza\w*|rotina da manha|bom dia fhinix resumo)\b/.test(n)) { runRoutine(); return 'Iniciando o resumo.'; }
      if (/\b(noticias?|manchetes?)\b/.test(n)) { const r = await getNews(); paintNews(r); return r.err ? errText(r.err, 'notícias') : newsText(r.data); }
      if (/\b(reunioes|reuniao|agenda|compromissos?|calendario)\b/.test(n)) { const r = await getAgenda(); paintAgenda(r); return r.err ? errText(r.err, 'Agenda') : agendaText(r.data); }
      if (/\be-?mails?\b|\bgmail\b|\bcaixa de entrada\b/.test(n)) { const r = await getEmails(); paintEmails(r); return r.err ? errText(r.err, 'Gmail') : emailsSpoken(r.data); }

      if (/\b(pausa|pausar|pause)\b|\b(pare|para|parar|desliga) (a )?musica\b/.test(n)) return viaSp(async () => { await sp.pause(); return 'Música pausada.'; });
      if (/\b(continua|continuar|retoma|retomar|despausar)\b|^(toque|toca|tocar|coloque|coloca) (uma |a )?(musica|som|spotify)$/.test(n)) return viaSp(async () => { await (n.includes('musica') || n.includes('spotify') || n.includes('som') ? sp.playConfig() : sp.resume()); return 'Tocando.'; });
      if (/\b(proxima|pula|pular|avanca)\b/.test(n)) return viaSp(async () => { await sp.next(); return 'Próxima.'; });
      if (/\b(anterior|voltar musica|volta a musica)\b/.test(n)) return viaSp(async () => { await sp.prev(); return 'Voltando.'; });
      if ((m = /\bvolume\b.*?\b(\d{1,3})\b/.exec(n))) return viaSp(async () => { await sp.setVolume(+m[1]); return 'Volume em ' + Math.min(100, +m[1]) + '.'; });
      if (/\b(aumenta|aumentar|sobe|subir)\b.*\bvolume\b|\bvolume (mais )?alto\b/.test(n)) return viaSp(async () => 'Volume em ' + (await sp.changeVolume(15)) + '.');
      if (/\b(abaixa|abaixar|diminui|diminuir|baixa|baixar)\b.*\bvolume\b|\bvolume (mais )?baixo\b/.test(n)) return viaSp(async () => 'Volume em ' + (await sp.changeVolume(-15)) + '.');
      if (/\bo que (esta |ta )?tocando\b|\bque musica (e )?essa\b|\bqual (e )?a musica\b/.test(n)) return viaSp(async () => { const t = await sp.nowPlaying(); paintNow(); return t ? t.name + ', de ' + t.artists + (t.playing ? '.' : ' (pausado).') : 'Nada está tocando.'; });
      if ((m = /^(?:toque|toca|tocar|coloque|coloca|ponha|poe|reproduza)\s+(.+)$/.exec(n))) {
        const q = m[1].replace(/\s+(no|pelo|na) spotify$/, '').trim();
        if (q.length > 1) return viaSp(async () => { const name = await sp.playQuery(q); paintNow(); return name ? 'Tocando ' + name + '.' : 'Não encontrei nada no Spotify para “' + q + '”.'; });
      }
      return null;
    }

    sp.handleRedirect().then(() => { refreshStatus(); paintNow(); });
    build();
    setInterval(refreshStatus, 30000);

    return {
      handle: handle, runRoutine: runRoutine, stop: stop, startClaps: startClaps, stopClaps: stopClaps, onDoubleClap: onDoubleClap,
      prime: () => sp.prime(), refreshStatus: refreshStatus, spotify: sp, get claps() { return !!mic; }
    };
  }

  window.FhinixHub = {
    create: create,
    _test: { ClapDetector: ClapDetector, fromSens: fromSens, scoreEmail: scoreEmail, triage: triage, normMsg: normMsg, parseFrom: parseFrom, cleanSubject: cleanSubject, splitTitle: splitTitle, emailsText: emailsText, agendaText: agendaText, newsText: newsText, spokenTime: spokenTime, safeUrl: safeUrl }
  };
})();
