// Configuração do Fhinix. A chave "apiKey" do Firebase Web não é segredo (ela só identifica o projeto);
// quem protege os dados são as regras do Firestore e o login Google.
window.FHINIX = {
  firebase: {
    apiKey: 'AIzaSyCYAImgMBlZ2uY4pwtNofyrfVbfAj-HpUo',
    authDomain: 'phonix-7a5fd.firebaseapp.com',
    projectId: 'phonix-7a5fd',
    storageBucket: 'phonix-7a5fd.firebasestorage.app',
    messagingSenderId: '856348411158',
    appId: '1:856348411158:web:4284f8b8735ef3fb5e7c37'
  },

  // ---- Voz (estilo Jarvis: grave, calma, pausada) ----
  // Usa as vozes instaladas no seu aparelho. Melhores resultados: Edge no Windows ("Microsoft Antonio Online", pt-BR, natural)
  // ou Safari/macOS ("Felipe"). Dá para trocar no Painel > Voz.
  voz: {
    preferida: 'Antonio', // trecho do nome da voz; vazio = escolha automática
    tom: 0.78,            // 0.5 (mais grave) a 1.2
    velocidade: 0.96      // 0.7 (lento) a 1.3
  },

  // ---- Spotify ----
  // 1) Crie um app em https://developer.spotify.com/dashboard
  // 2) Em "Redirect URIs" cadastre EXATAMENTE: https://phonix-7a5fd.web.app/   (e, para testar local, http://127.0.0.1:5000/)
  // 3) Cole o "Client ID" abaixo (não use o Client Secret: ele não é necessário e não deve ficar aqui).
  spotify: {
    clientId: 'COLE_AQUI',
    playlist: '',        // opcional: link ou URI de uma playlist/álbum/artista para tocar nas palmas. Vazio = retoma o que estava tocando.
    aleatorio: true,     // embaralhar a playlist
    volume: 70,          // volume normal (0 a 100)
    volumeFundo: 30      // volume enquanto o Fhinix fala
  },

  // ---- Palmas ----
  palmas: {
    ativo: true,
    quantidade: 2,       // quantas palmas seguidas acionam (2 = duas palmas)
    sensibilidade: 5     // 1 (menos sensível) a 10 (mais sensível). Ajustável no Painel, com medidor ao vivo.
  },

  // ---- Resumo do dia ----
  resumo: {
    ordem: ['noticias', 'agenda', 'emails'],
    maxEmails: 5,
    notaMin: 3,          // nota mínima de importância para o e-mail ser lido (3 = equilibrado; 5 = mais rígido)
    vips: [],            // ex.: ['chefe@empresa.com', 'maria'] - e-mails desses remetentes sempre entram
    bloquear: [],        // ex.: ['linkedin', 'rappi'] - remetentes que nunca entram
    consultaGmail: 'is:unread in:inbox newer_than:2d',
    sempreResumo: false  // false: se a música já estiver tocando, as palmas pausam; true: as palmas sempre fazem o resumo
  },

  // ---- Notícias ----
  noticias: {
    max: 5
    // feeds: ['https://news.google.com/rss?hl=pt-BR&gl=BR&ceid=BR:pt-419', 'https://g1.globo.com/rss/g1/']
  }

  // Modelo da IA local (opcional). Para aparelhos mais fracos: model: 'Qwen2.5-0.5B-Instruct-q4f16_1-MLC'
};
